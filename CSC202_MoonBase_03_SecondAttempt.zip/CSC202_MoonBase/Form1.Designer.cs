﻿namespace CSC202_MoonBase
{
    partial class FM1moonbase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FM1moonbase));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BTNenter = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TBextDesc = new System.Windows.Forms.TextBox();
            this.TBexterior = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BTNenter);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TBextDesc);
            this.groupBox1.Controls.Add(this.TBexterior);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(881, 301);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 369);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "International Community Consortium Moon Base";
            // 
            // BTNenter
            // 
            this.BTNenter.Location = new System.Drawing.Point(157, 298);
            this.BTNenter.Name = "BTNenter";
            this.BTNenter.Size = new System.Drawing.Size(133, 65);
            this.BTNenter.TabIndex = 1;
            this.BTNenter.Text = "Enter";
            this.BTNenter.UseVisualStyleBackColor = true;
            this.BTNenter.Click += new System.EventHandler(this.BTNenter_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Location Description";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // TBextDesc
            // 
            this.TBextDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBextDesc.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBextDesc.Location = new System.Drawing.Point(33, 132);
            this.TBextDesc.Multiline = true;
            this.TBextDesc.Name = "TBextDesc";
            this.TBextDesc.ReadOnly = true;
            this.TBextDesc.Size = new System.Drawing.Size(380, 160);
            this.TBextDesc.TabIndex = 1;
            this.TBextDesc.Text = resources.GetString("TBextDesc.Text");
            // 
            // TBexterior
            // 
            this.TBexterior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBexterior.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBexterior.Location = new System.Drawing.Point(33, 62);
            this.TBexterior.Name = "TBexterior";
            this.TBexterior.ReadOnly = true;
            this.TBexterior.Size = new System.Drawing.Size(380, 21);
            this.TBexterior.TabIndex = 2;
            this.TBexterior.Text = "ICC Moon Base Exterior";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Location Name";
            // 
            // FM1moonbase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1344, 682);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FM1moonbase";
            this.Text = "ICC Moon Base";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBexterior;
        private System.Windows.Forms.TextBox TBextDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTNenter;
    }
}

