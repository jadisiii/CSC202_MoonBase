﻿/* 
 Ray Arbizu
 Moon Base Assignement, second attempt
 Form 1 - The starting 'form' of this application
 Including documentation of the code
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_MoonBase
{
    public partial class FM1moonbase : Form //This is the begining of the code for Form1
    {
        public FM1moonbase() // This is where the constructor starts
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // This is where I would pu the code if I wanted to do something when clicking on label2
        }

        private void BTNenter_Click(object sender, EventArgs e)
        {
            // When clicking on the Enter button, the following code will execute
            MessageBox.Show("You are now entering the ICC Moon Base."); // A message box will appear with text
            FMinterior frm = new FMinterior(); // This code puts the other form 'FMinterior' into the variable frm
            this.Hide(); // Signifies that we will hid this form 'Form1'
            frm.Show(); // Signifies that ware are going to show 'frm' which is the form 'FMinterior' , in the 'frm' variable
        }
    }
}
