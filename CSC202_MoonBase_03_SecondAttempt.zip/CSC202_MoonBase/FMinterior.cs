﻿/*
 Ray Arbizu
 Moon Base Assignement, second attempt
 Form: FMinterior - The starting 'form' of this application
 Including documentation of the code
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_MoonBase
{
    public partial class FMinterior : Form //This is the begining of the code for FMinterior
    {
        public FMinterior()
        {
            InitializeComponent(); // This is where the constructor starts
        }

        private void BTNexit_Click(object sender, EventArgs e)
        {
            // When clicking on the Enter button, the following code will execute
            MessageBox.Show("You are now leaving the ICC Moon Base."); // A message box will appear with text that we are leaving the moon base
            FM1moonbase frm = new FM1moonbase(); // This code puts the other form 'FMmoonbase' or 'Form1' into the variable frm
            this.Hide(); // Signifies that we will hide this form 'FMinterior'
            frm.Show(); // Signifies that ware are going to show 'frm' which is the form 'FMmoonbase' , in the 'frm' variable
        }
    }
}
