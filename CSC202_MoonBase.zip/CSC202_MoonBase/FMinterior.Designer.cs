﻿namespace CSC202_MoonBase
{
    partial class FMinterior
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMinterior));
            this.GBinterior = new System.Windows.Forms.GroupBox();
            this.BTNexit = new System.Windows.Forms.Button();
            this.LBLlocationDesc = new System.Windows.Forms.Label();
            this.TBlabStudyDesc = new System.Windows.Forms.TextBox();
            this.TBinterior = new System.Windows.Forms.TextBox();
            this.LBLlocationName = new System.Windows.Forms.Label();
            this.GBinterior.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBinterior
            // 
            this.GBinterior.Controls.Add(this.BTNexit);
            this.GBinterior.Controls.Add(this.LBLlocationDesc);
            this.GBinterior.Controls.Add(this.TBlabStudyDesc);
            this.GBinterior.Controls.Add(this.TBinterior);
            this.GBinterior.Controls.Add(this.LBLlocationName);
            this.GBinterior.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBinterior.Location = new System.Drawing.Point(1461, 604);
            this.GBinterior.Name = "GBinterior";
            this.GBinterior.Size = new System.Drawing.Size(451, 369);
            this.GBinterior.TabIndex = 1;
            this.GBinterior.TabStop = false;
            this.GBinterior.Text = "International Community Consortium Moon Base";
            // 
            // BTNexit
            // 
            this.BTNexit.Location = new System.Drawing.Point(157, 298);
            this.BTNexit.Name = "BTNexit";
            this.BTNexit.Size = new System.Drawing.Size(133, 65);
            this.BTNexit.TabIndex = 1;
            this.BTNexit.Text = "Exit";
            this.BTNexit.UseVisualStyleBackColor = true;
            this.BTNexit.Click += new System.EventHandler(this.BTNexit_Click);
            // 
            // LBLlocationDesc
            // 
            this.LBLlocationDesc.AutoSize = true;
            this.LBLlocationDesc.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLlocationDesc.Location = new System.Drawing.Point(30, 111);
            this.LBLlocationDesc.Name = "LBLlocationDesc";
            this.LBLlocationDesc.Size = new System.Drawing.Size(165, 18);
            this.LBLlocationDesc.TabIndex = 1;
            this.LBLlocationDesc.Text = "Location Description";
            // 
            // TBlabStudyDesc
            // 
            this.TBlabStudyDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBlabStudyDesc.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBlabStudyDesc.Location = new System.Drawing.Point(33, 132);
            this.TBlabStudyDesc.Multiline = true;
            this.TBlabStudyDesc.Name = "TBlabStudyDesc";
            this.TBlabStudyDesc.ReadOnly = true;
            this.TBlabStudyDesc.Size = new System.Drawing.Size(380, 160);
            this.TBlabStudyDesc.TabIndex = 1;
            this.TBlabStudyDesc.Text = resources.GetString("TBlabStudyDesc.Text");
            // 
            // TBinterior
            // 
            this.TBinterior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TBinterior.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBinterior.Location = new System.Drawing.Point(33, 62);
            this.TBinterior.Name = "TBinterior";
            this.TBinterior.ReadOnly = true;
            this.TBinterior.Size = new System.Drawing.Size(380, 21);
            this.TBinterior.TabIndex = 2;
            this.TBinterior.Text = "Research Pod Study";
            // 
            // LBLlocationName
            // 
            this.LBLlocationName.AutoSize = true;
            this.LBLlocationName.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLlocationName.Location = new System.Drawing.Point(30, 41);
            this.LBLlocationName.Name = "LBLlocationName";
            this.LBLlocationName.Size = new System.Drawing.Size(119, 18);
            this.LBLlocationName.TabIndex = 1;
            this.LBLlocationName.Text = "Location Name";
            // 
            // FMinterior
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 985);
            this.Controls.Add(this.GBinterior);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FMinterior";
            this.Text = "ICC Moon Base";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.GBinterior.ResumeLayout(false);
            this.GBinterior.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBinterior;
        private System.Windows.Forms.Button BTNexit;
        private System.Windows.Forms.Label LBLlocationDesc;
        private System.Windows.Forms.TextBox TBlabStudyDesc;
        private System.Windows.Forms.TextBox TBinterior;
        private System.Windows.Forms.Label LBLlocationName;
    }
}