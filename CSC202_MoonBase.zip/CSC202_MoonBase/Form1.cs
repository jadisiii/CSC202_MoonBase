﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_MoonBase
{
    public partial class FM1moonbase : Form
    {
        public FM1moonbase()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BTNenter_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are now entering the ICC Moon Base.");
            FMinterior frm = new FMinterior();
            this.Hide();
            frm.Show();
        }
    }
}
