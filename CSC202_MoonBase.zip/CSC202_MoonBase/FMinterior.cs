﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC202_MoonBase
{
    public partial class FMinterior : Form
    {
        public FMinterior()
        {
            InitializeComponent();
        }

        private void BTNexit_Click(object sender, EventArgs e)
        {
            FM1moonbase frm = new FM1moonbase();
            this.Hide();
            frm.Show();
        }
    }
}
